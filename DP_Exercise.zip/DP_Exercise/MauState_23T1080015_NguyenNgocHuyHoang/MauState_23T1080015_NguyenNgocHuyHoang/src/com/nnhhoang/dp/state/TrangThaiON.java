package com.nnhhoang.dp.state;

public class TrangThaiON implements ITrangThai{
	@Override
	public void bamNutON(TV tv) {
		System.out.println("Đang ON. Bấm thêm ON không có tác dụng gì!!!!!!!!!!!!");
	}

	@Override
	public void bamNutOFF(TV tv) {
		System.out.println("Đang ON. Bấm OFF chuyển sang trạng thái OFF -- Tắt TV");
		tv.setTrangThai(new TrangThaiOFF());
	}

	@Override
	public void bamNutMUTE(TV tv) {
		System.out.println("Đang ON và không MUTE. Thiết lập TV ở trạng thái MUTE");
		tv.setTrangThai(new TrangThaiMUTE());
	}
}
