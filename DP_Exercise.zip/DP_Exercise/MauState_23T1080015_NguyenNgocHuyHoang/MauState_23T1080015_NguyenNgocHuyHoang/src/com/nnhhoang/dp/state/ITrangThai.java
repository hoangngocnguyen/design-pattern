package com.nnhhoang.dp.state;

public interface ITrangThai {
	void bamNutON(TV tv);

	void bamNutOFF(TV tv);

	void bamNutMUTE(TV tv);
}
