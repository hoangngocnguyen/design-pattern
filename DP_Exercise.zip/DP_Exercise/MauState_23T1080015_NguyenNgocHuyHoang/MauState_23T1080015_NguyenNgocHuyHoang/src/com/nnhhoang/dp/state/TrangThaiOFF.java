package com.nnhhoang.dp.state;

public class TrangThaiOFF implements ITrangThai{

	@Override
	public void bamNutON(TV tv) {
		System.out.println("Đang OFF. Bấm ON chuyển TV sang chế độ ONNNNN");
		tv.setTrangThai(new TrangThaiON());
	}

	@Override
	public void bamNutOFF(TV tv) {
		System.out.println("Đang OFF. Bấm OFF nữa không có tác dụng gì");
	}

	@Override
	public void bamNutMUTE(TV tv) {
		System.out.println("Đang OFF thì bấm MUTE làm gì!!!!!!");
	}

}
