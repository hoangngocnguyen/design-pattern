package com.nnhhoang.dp.state;

public class ChuongTrinh {
	public static void main(String[] args) {
		TV tv = new TV();
		System.out.println("Trạng thái hiện tại là " + tv.getTrangThai());
		
		tv.bamNutOFF();
		tv.bamNutMUTE();
		tv.bamNutOFF();
		tv.bamNutON();
		tv.bamNutMUTE();
		tv.bamNutMUTE();
		tv.bamNutMUTE();
		tv.bamNutOFF();
		tv.bamNutMUTE();
		tv.bamNutON();
	}
}
