package com.nnhhoang.dp.state;

public class TV {
	private ITrangThai trangThaiHienTai;
	public void setTrangThai(ITrangThai trangThai) {
		this.trangThaiHienTai = trangThai;
	}

	public ITrangThai getTrangThai() {
		return this.trangThaiHienTai;
	}

	public void bamNutON() {
		this.trangThaiHienTai.bamNutON(this);
	}

	public void bamNutOFF() {
		this.trangThaiHienTai.bamNutOFF(this);
	}

	public void bamNutMUTE() {
		this.trangThaiHienTai.bamNutMUTE(this);
	}

	/**
	 * Hàm khởi dựng -- có thể thiết lập trạng thái đầu tiên Hoặc nếu thích có thể
	 * bổ sung vào 1 tham số làm trạng thái đầu tiên
	 */
	public TV() {
		this.trangThaiHienTai = new TrangThaiOFF();
	}

	public TV(ITrangThai trangthai) {
		this.setTrangThai(trangthai);
	}
}
