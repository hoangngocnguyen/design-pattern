package com.nnhhoang.dp.state;

public class TrangThaiMUTE implements ITrangThai{
	@Override
	public void bamNutON(TV tv) {
		System.out.println("TV đang ở trạng thái MUTE. Bấm thêm ON không có tác dụng gì! Nó đang được ON mà");
	}

	@Override
	public void bamNutOFF(TV tv) {
		System.out.println("TV đang ở trạng thái MUTE. Bấm OFF chuyển sang trạng thái OFF -- Tắt TV");
		tv.setTrangThai(new TrangThaiOFF());
	}

	@Override
	public void bamNutMUTE(TV tv) {
		System.out.println("Đang MUTE. Bấm MUTE nữa thì xem như ON và bình thường");
		tv.setTrangThai(new TrangThaiON());
	}
}
