package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import hoang_singleton.KetNoi;

public class NganhDaoTaoDAO {
	private static List<NganhDaoTao> _cachedList = null;
	private static LocalDateTime _thoiDiemBuildCache = LocalDateTime.MIN;

	public List<NganhDaoTao> selectAll() throws SQLException {
		LocalDateTime now = LocalDateTime.now();
		LocalDateTime deadline = _thoiDiemBuildCache.plusHours(8);

		if (_cachedList == null || (now.isAfter(deadline))) {
			System.out.println("Đây là lần đầu tiên SELECT danh sách NgànhĐàoTạo");
			
			_cachedList = new ArrayList<NganhDaoTao>();
			
			String sql = "SELECT * FROM nganh_dao_tao";

			Connection conn = KetNoi.getInstance().getConnection();

			try (PreparedStatement pstmt = conn.prepareStatement(sql); ResultSet rs = pstmt.executeQuery()) {

				while (rs.next()) {
					String maNganh = rs.getString("MaNganh");
					String tenNganh = rs.getString("TenNganh");

					NganhDaoTao ndt = new NganhDaoTao(maNganh, tenNganh);
					_cachedList.add(ndt);
				}
			} catch (SQLException e) {
				System.err.println("Lỗi khi lấy danh sách ngành đào tạo: " + e.getMessage());
				e.printStackTrace();
			}
			
			_thoiDiemBuildCache = LocalDateTime.now();
			System.out.println("Đã lấy xong danh sách NgànhĐàoTạo");
		}

		System.out.println("Trả về danh sách");

		return _cachedList;
	}
	
	public void xuatThongTin(List<NganhDaoTao> list) {
        if (list == null || list.isEmpty()) {
            System.out.println("Danh sách trống.");
            return;
        }

        System.out.println("==========================================");
        System.out.printf("%-15s | %-25s\n", "Mã Ngành", "Tên Ngành");
        System.out.println("------------------------------------------");

        for (NganhDaoTao ndt : list) {
            System.out.printf("%-15s | %-25s\n", ndt.getMaNganh(), ndt.getTenNganh());
        }
    }
}
