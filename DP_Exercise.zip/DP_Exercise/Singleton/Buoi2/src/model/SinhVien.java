package model;

public class SinhVien {
	private String hoTen;
	private String maSinhVien;
	private double diemTrungBinh;

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public String getMaSinhVien() {
		return maSinhVien;
	}

	public void setMaSinhVien(String maSinhVien) {
		this.maSinhVien = maSinhVien;
	}

	public double getDiemTrungBinh() {
		return diemTrungBinh;
	}

	public void setDiemTrungBinh(double diemTrungBinh) {
		this.diemTrungBinh = diemTrungBinh;
	}
	
	public String getInfo() {
		return String.format("%s, %s, %.2f", this.maSinhVien, this.hoTen,this.diemTrungBinh);
	}

	public SinhVien(String hoTen, String maSinhVien, double diemTrungBinh) {
		super();
		this.hoTen = hoTen;
		this.maSinhVien = maSinhVien;
		this.diemTrungBinh = diemTrungBinh;
	}
}