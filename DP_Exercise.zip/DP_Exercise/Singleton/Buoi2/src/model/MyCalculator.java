package model;

import java.util.HashMap;

public class MyCalculator {
	private HashMap<String, Double> _cache = new HashMap<String, Double>();

	public double getKetQuaPhepTinh(double a, double b, String phepTinh) {
		String baiToan = a + phepTinh + b;

		double kq;
		if (_cache.containsKey(baiToan)) {
			// Đã lưu bài toán vào cache
			kq = _cache.get(baiToan);
		} else {

			// Chưa làm
			if (phepTinh.contains("+"))
				kq = a + b;
			else if (phepTinh.equals("-"))
				kq = a - b;
			else if (phepTinh.equals("*"))
				kq = a * b;
			else
				kq = a / b;
			
			// Lưu bài toán vào
			_cache.put(baiToan, kq);

			try {
				System.out.println("Vui lòng chờ trong 5s");
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		return kq;
	}

}
