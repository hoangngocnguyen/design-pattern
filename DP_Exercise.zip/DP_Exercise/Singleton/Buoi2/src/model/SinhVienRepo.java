package model;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import hoang_singleton.KetNoi;

public class SinhVienRepo {
	public static List<SinhVien> docDanhSachSinhVienTuCSDL() throws SQLException {
		List<SinhVien> lst = new ArrayList<SinhVien>();
		
		KetNoi kn = KetNoi.getInstance();
		String query = "select * from sinhvien";
		
		try {
			PreparedStatement ps = kn.getConnection().prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				String maSV = rs.getString("MaSinhVien");
				String hoTen = rs.getString("HoTen");
				double diemTB = rs.getDouble("DiemTB");
				
				lst.add(new SinhVien(hoTen, maSV, diemTB));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return lst;
	}
	
	public static void inDanhSachSinhVien(List<SinhVien> lst) {
		// Sap xep sinh vien theo thu tu ABC
//		lst.sort((sv1, sv2) -> sv1.getHoTen().compareTo(sv2.getHoTen()));
		
		// Sap xep sinh vien giam dan theo dtb
		lst.sort((sv1, sv2) -> Double.compare(sv2.getDiemTrungBinh(), sv1.getDiemTrungBinh()));
		
		for (SinhVien sv : lst) {
			System.out.println(sv.getInfo());
		}
	}
	
	
	
}
