package chuongtrinh;

import java.util.Scanner;

import model.MyCalculator;

public class ChuongTrinhMayTinh {
	public static void main(String[] args) {
		testMayTinh();
	}
	
	public static void testMayTinh() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhap a");
		double a = sc.nextDouble();
		
		System.out.println("Nhap b");
		double b = sc.nextDouble();
		
		System.out.println("Nhap phep toan (+-*/)");
		sc.nextLine();
		String phepTinh = sc.nextLine();
		
		MyCalculator mayTinh = new MyCalculator();
		System.out.println(a + phepTinh + b + "= " + mayTinh.getKetQuaPhepTinh(a, b, phepTinh));
		
		// Tính lại lần 2
		System.out.println(a + phepTinh + b + "= " + mayTinh.getKetQuaPhepTinh(a, b, phepTinh));
		
		// Tính test
		System.out.println(1.4 + "+" + 1.6 + "= " + mayTinh.getKetQuaPhepTinh(1.4, 1.6, "+"));
	}
}
