package chuongtrinh;
import java.sql.SQLException;

import model.NganhDaoTaoDAO;

public class ChuongTrinhVD2 {
	public static void main(String[] args) throws SQLException {
		testNganhDaoTaoDAO();

		anotherMethod();
	}

	private static void anotherMethod() throws SQLException {
		System.out.println("anotherMethod");
		NganhDaoTaoDAO dao = new NganhDaoTaoDAO();

		var lst = dao.selectAll();
		dao.xuatThongTin(lst);
	}

	private static void testNganhDaoTaoDAO() throws SQLException {
		System.out.println("testNganhDaoTaoDAO");
		NganhDaoTaoDAO dao = new NganhDaoTaoDAO();

		var lst = dao.selectAll();
		dao.xuatThongTin(lst);
	}
}
