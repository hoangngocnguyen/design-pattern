package hoang_singleton;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KetNoi {
	private static KetNoi _instance = null;
	private Connection _connection;
	

	private KetNoi() throws SQLException {
		String url = "jdbc:mysql://localhost:3306/sinhvien";
        String user = "root";
        String password = "123456";

        _connection = DriverManager.getConnection(url, user, password);
        System.out.println("Kết nối MySQL thành công!");
	}
	
	public static KetNoi getInstance() throws SQLException {
		if (_instance == null) {
			_instance = new KetNoi();
		}
		return _instance;
	}
	
	public Connection getConnection() { return _connection; }
}

