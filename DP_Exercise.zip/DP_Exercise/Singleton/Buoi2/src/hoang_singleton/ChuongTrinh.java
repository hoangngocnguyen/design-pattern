package hoang_singleton;

import java.sql.SQLException;
import java.util.List;

import model.SinhVien;
import model.SinhVienRepo;

public class ChuongTrinh {
	public static void main(String[] args) throws SQLException {
//		KetNoi kn1 = KetNoi.getInstance();
//		KetNoi kn2 = KetNoi.getInstance();
//		KetNoi kn3 = new KetNoi();
		
	
		List<SinhVien> lst = SinhVienRepo.docDanhSachSinhVienTuCSDL();
		List<SinhVien> lst2 = SinhVienRepo.docDanhSachSinhVienTuCSDL();
		
		SinhVienRepo.inDanhSachSinhVien(lst);
		
		// Ket qua: Dù gọi hàm đọc 2 lần => nhưng chỉ in ra dòng Kết nối MySQL thành công 1 lần.
	}
}
