package vn.edu.husc.t1080015.prototype;

@lombok.Data
public class SinhVienTaiChuc extends SinhVien{
	private String coQuan;
	private double heSoLuong;
	
	public SinhVienTaiChuc(SinhVienTaiChuc x) {
		super(x);
		this.coQuan = x.coQuan;
		this.heSoLuong = x.heSoLuong;
	}
	
	public SinhVienTaiChuc(String maSV, String hoten, String coQuan, double heSoLuong) {
		this.setHoTen(hoten);
		this.setMaSinhVien(maSV);
		this.setCoQuan(coQuan);
		this.setHeSoLuong(heSoLuong);
	}
	
	@Override
	public SinhVien taoBanSao() {
		return new SinhVienTaiChuc(this);
	}
	

	public String toString() {
		return String.format("Sinh viên tại chức %s thuộc cơ quan %s, hệ số lương là %f", 
				this.getHoTen(), this.getCoQuan(), this.getHeSoLuong());
	}
}
