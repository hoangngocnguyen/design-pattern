package vn.edu.husc.t1080015.prototype;

@lombok.Data
public class SinhVienNuocNgoai extends SinhVien{
	private String quocGia;
	
	// Lombok khong ap dung constructor ke thua
	public SinhVienNuocNgoai(String maSV, String hoten, String quocGia) {
		this.setHoTen(hoten);;
		this.setMaSinhVien(maSV);
		this.setQuocGia(quocGia);
	}
	
	public SinhVienNuocNgoai(SinhVienNuocNgoai x) {
		super(x);
		this.setQuocGia(x.quocGia);
	}
	
	@Override
	public SinhVien taoBanSao() {
		return new SinhVienNuocNgoai(this);
	}

	public String toString() {
		return String.format("Sinh viên nước ngoài %s có quốc tịch là: %s", 
				this.getHoTen(), this.getQuocGia());
	}
}
