package vn.edu.husc.t1080015.prototype;

import java.util.ArrayList;
import java.util.List;

public class ChuongTrinh {
	public static void main(String[] args) {
		test();
	}

	private static void test() {
		// Khởi tạo danh sách
		List<SinhVien> lst1 = new ArrayList<>();

		lst1.add(new SinhVien("23T1080004", "Nguyễn Quốc Đạt"));
		lst1.add(new SinhVienNuocNgoai("23T1080005", "Lê Bê La", "Công ty SALA"));
		lst1.add(new SinhVienNuocNgoai("23T1080025", "Trần Đại", "Công ty Đại Phát"));
		lst1.add(new SinhVien("23T1080022", "Chân Tử Đan"));
		lst1.add(new SinhVienTaiChuc("sv015", "Hoàng Nguyễn", "Ngân hàng Á Châu", 3.4f));

		System.out.println("DANH SÁCH GỐC");
		for (int i = 0; i < lst1.size(); i++)
			System.out.println(lst1.get(i).toString());

		System.out.println("\nTẠO BẢN SAO KIỂU 1");
//		// Tạo bản sao
		List<SinhVien> lst2 = new ArrayList<>();
		for (int i = 0; i < lst1.size(); i++) {
			SinhVien x = lst1.get(i);
//			if (x instanceof SinhVienNuocNgoai)
//				lst2.add(new SinhVienNuocNgoai((SinhVienNuocNgoai) x));
//			else
//				lst2.add(new SinhVien(x));
			lst2.add(x.taoBanSao());
		}

		// In danh sách bản sao
		for (int i = 0; i < lst2.size(); i++)
			System.out.println(lst2.get(i).toString());
	}
}
