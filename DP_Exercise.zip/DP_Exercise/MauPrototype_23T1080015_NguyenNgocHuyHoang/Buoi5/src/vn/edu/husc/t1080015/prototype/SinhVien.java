package vn.edu.husc.t1080015.prototype;

@lombok.Data
@lombok.NoArgsConstructor
@lombok.AllArgsConstructor
public class SinhVien {
	private String maSinhVien;
	private String hoTen;

	public SinhVien(SinhVien x) {
		this.maSinhVien = x.maSinhVien;
		this.hoTen = x.hoTen;
	}
	
	public SinhVien taoBanSao() {
		// Khởi tạo đối tượng mới là bản sao đối tượng cũ
		return new SinhVien(this);
	}

	
	public String toString() {
		return "Sinh viên " + this.getHoTen();				
	}	
}
