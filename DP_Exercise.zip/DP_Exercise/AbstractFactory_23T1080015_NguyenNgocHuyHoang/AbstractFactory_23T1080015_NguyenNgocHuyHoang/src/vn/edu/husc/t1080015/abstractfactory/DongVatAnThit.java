package vn.edu.husc.t1080015.abstractfactory;

public interface DongVatAnThit {
	void duoi(DongVatAnCo x);
}
