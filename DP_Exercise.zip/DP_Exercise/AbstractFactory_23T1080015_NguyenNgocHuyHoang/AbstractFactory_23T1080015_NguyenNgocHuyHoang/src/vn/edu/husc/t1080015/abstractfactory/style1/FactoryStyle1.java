package vn.edu.husc.t1080015.abstractfactory.style1;

import vn.edu.husc.t1080015.abstractfactory.DongVatAnCo;
import vn.edu.husc.t1080015.abstractfactory.DongVatAnThit;
import vn.edu.husc.t1080015.abstractfactory.DongVatFactory;

public class FactoryStyle1 extends DongVatFactory{

	@Override
	public DongVatAnThit taoDongVatAnThit() {
		return new SuTu();
	}

	@Override
	public DongVatAnCo taoDongVatAnCo() {
		return new NguaVan();
	}
	
}
