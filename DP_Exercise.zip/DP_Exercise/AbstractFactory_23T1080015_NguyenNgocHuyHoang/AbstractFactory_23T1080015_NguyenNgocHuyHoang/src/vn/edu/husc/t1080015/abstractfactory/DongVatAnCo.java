package vn.edu.husc.t1080015.abstractfactory;

public interface DongVatAnCo {
	void boChay();
}
