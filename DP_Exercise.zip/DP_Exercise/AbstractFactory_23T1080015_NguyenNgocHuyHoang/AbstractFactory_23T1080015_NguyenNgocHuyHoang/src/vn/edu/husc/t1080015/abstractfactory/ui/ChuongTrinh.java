package vn.edu.husc.t1080015.abstractfactory.ui;

import vn.edu.husc.t1080015.abstractfactory.DongVatAnCo;
import vn.edu.husc.t1080015.abstractfactory.DongVatAnThit;
import vn.edu.husc.t1080015.abstractfactory.DongVatFactory;
import vn.edu.husc.t1080015.abstractfactory.style1.FactoryStyle1;
import vn.edu.husc.t1080015.abstractfactory.style2.FactoryStyle2;

public class ChuongTrinh {
	public static void main(String[] args) {
		test();
	}

	private static void test() {
		// 1. Tạo nhà máy theo style
		DongVatFactory f;
		
		String style = "1";
		System.out.println("Style đang áp dụng: " + style);
		
		if (style.equals("1")) {
			f = new FactoryStyle1();		
		} else if (style.equals("2")) {
			f = new FactoryStyle2();
		} else {
			f = null;
		}
		
		// 2. Tạo và sử dụng các đối tượng thuộc hệ sinh thái của nhà máy đó
		DongVatAnThit dvAnThit = f.taoDongVatAnThit();
		DongVatAnCo dvAnCo = f.taoDongVatAnCo();
		
		// 3. Sử dụng các đối tượng cùng style
		dvAnThit.duoi(dvAnCo);
	}

}
