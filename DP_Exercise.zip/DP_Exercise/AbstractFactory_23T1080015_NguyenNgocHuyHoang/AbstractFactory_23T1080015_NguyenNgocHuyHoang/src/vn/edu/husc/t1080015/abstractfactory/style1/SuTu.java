package vn.edu.husc.t1080015.abstractfactory.style1;

import vn.edu.husc.t1080015.abstractfactory.DongVatAnCo;
import vn.edu.husc.t1080015.abstractfactory.DongVatAnThit;

public class SuTu implements DongVatAnThit{

	@Override
	public void duoi(DongVatAnCo x) {
		System.out.println("Sư tử đang săn đuổi\n" + this.toString());
		x.boChay();
	}

}
