package vn.edu.husc.t1080015.abstractfactory.style1;

import vn.edu.husc.t1080015.abstractfactory.DongVatAnCo;

public class NguaVan implements DongVatAnCo{

	@Override
	public void boChay() {
		System.out.println("Ngựa vằn sợ bỏ chạy");
	}

}
