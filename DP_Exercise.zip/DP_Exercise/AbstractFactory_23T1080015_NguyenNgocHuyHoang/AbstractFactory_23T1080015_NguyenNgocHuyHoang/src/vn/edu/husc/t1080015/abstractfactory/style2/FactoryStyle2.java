package vn.edu.husc.t1080015.abstractfactory.style2;

import vn.edu.husc.t1080015.abstractfactory.DongVatAnCo;
import vn.edu.husc.t1080015.abstractfactory.DongVatAnThit;
import vn.edu.husc.t1080015.abstractfactory.DongVatFactory;

public class FactoryStyle2 extends DongVatFactory {

	@Override
	public DongVatAnThit taoDongVatAnThit() {
		return new SoiRung();
	}

	@Override
	public DongVatAnCo taoDongVatAnCo() {
		return new Soc();
	}

}
