package vn.edu.husc.t1080015.abstractfactory;

public abstract class DongVatFactory {
	public abstract DongVatAnThit taoDongVatAnThit();
	public abstract DongVatAnCo taoDongVatAnCo();
}
