package vn.edu.husc.t1080015.abstractfactory.style2;

import vn.edu.husc.t1080015.abstractfactory.DongVatAnCo;
import vn.edu.husc.t1080015.abstractfactory.DongVatAnThit;

public class SoiRung implements DongVatAnThit{

	@Override
	public void duoi(DongVatAnCo x) {
		System.out.println("Sói đang săn đuổi\n" + this.toString());
		x.boChay();
	}
	
}
