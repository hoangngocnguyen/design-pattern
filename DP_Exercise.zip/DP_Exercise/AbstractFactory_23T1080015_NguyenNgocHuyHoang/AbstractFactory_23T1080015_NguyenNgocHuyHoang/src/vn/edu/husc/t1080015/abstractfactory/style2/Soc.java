package vn.edu.husc.t1080015.abstractfactory.style2;

import vn.edu.husc.t1080015.abstractfactory.DongVatAnCo;

public class Soc implements DongVatAnCo{

	@Override
	public void boChay() {
		System.out.println("Sóc sợ bỏ chạy");
	}

}
