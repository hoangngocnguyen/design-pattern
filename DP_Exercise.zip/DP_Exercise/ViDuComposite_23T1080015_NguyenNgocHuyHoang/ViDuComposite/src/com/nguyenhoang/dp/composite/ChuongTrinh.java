package com.nguyenhoang.dp.composite;

import java.sql.SQLException;
import java.util.Arrays;

public class ChuongTrinh {
	public static void main(String[] args) throws SQLException {
		/*
		LAPTRINH
		|__JAVA
		|    |__baitap01 (5 kb)
		|    |__baitap02 (3 kb)
		|    |__LYTHUYET
		|        |__abc (12 kb)
		|__C#
		|__test (1 kb)		 
		*/
		Component baitap01 	= new File("baitap01", 5);
		Component baitap02 	= new File("baitap02", 3);
		Component abc 		  = new File("abc", 12);
		Component test 		  = new File("test", 1);
		
		Component LYTHUYET 	= new Folder("LY THUYET", Arrays.asList(abc));
		Component JAVA 		  = new Folder("JAVA", Arrays.asList(baitap01, baitap02, LYTHUYET));
		Component CSHARP 	  = new Folder("C#", Arrays.asList());		
		Component LAPTRINH 	= new Folder("LAP TRINH", Arrays.asList(JAVA, CSHARP, test));
		
		System.out.println("Kich thuoc cua CSHARP la: " + CSHARP.getTotalSize());
		System.out.println("Kich thuoc cua LAPTRINH la: " + LAPTRINH.getTotalSize());
		System.out.println("Kich thuoc cua abc la: " + abc.getTotalSize());
		
		System.out.println();
		System.out.println(LAPTRINH.getPath("baitap02"));
		System.out.println(LAPTRINH.getPath("LY THUYET"));
	}
}
