package _23T1080015;

import java.util.List;

public class SinhVienDAOFactory {
	public SinhVienDAO getDAO() {
		// Đọc file cấu hình
		List<String> configs = Utils.docFileCauHinh();
		
		String loaiNguonDuLieu = configs.get(0);
		String duongDan = configs.get(1);
		
		// Tạo SinhVienDao theo loại nguồn
		if ("TEXT_FILE".equals(loaiNguonDuLieu)) {
			return new TextSinhVienDAO(duongDan);
		} else if ("MS_SQLSERVER".equals(loaiNguonDuLieu)) {
			return new DbSinhVienDAO(duongDan);
		}
		
		return null;
	}
}
