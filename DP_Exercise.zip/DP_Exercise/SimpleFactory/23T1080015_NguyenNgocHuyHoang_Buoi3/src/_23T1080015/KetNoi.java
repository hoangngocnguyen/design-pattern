package _23T1080015;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KetNoi {
	
	private static KetNoi _instance;
	private Connection _connection;
	
	private KetNoi(String connectionString) throws SQLException {
        _connection = DriverManager.getConnection(connectionString);
        System.out.println("Kết nối với CSDL thành công!");
	}
	
	public static KetNoi getInstance(String connectionString) throws SQLException {
		if (_instance == null) {
			_instance = new KetNoi(connectionString);
		}
		return _instance;
	}

	public Connection getConnection() {
		return _connection;
	}
}
