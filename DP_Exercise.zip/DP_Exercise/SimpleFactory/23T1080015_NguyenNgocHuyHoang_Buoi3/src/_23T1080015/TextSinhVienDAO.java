package _23T1080015;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TextSinhVienDAO implements SinhVienDAO {
	private String filename;

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public TextSinhVienDAO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TextSinhVienDAO(String filename) {
		super();
		this.filename = filename;
	}

	@Override
	public List<SinhVien> docDanhSach() {
		List<SinhVien> lst = new ArrayList<SinhVien>();

		// mo file
		// "sinhvien.txt" ~ filename
		try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
			while (true) {
				// doc tung dong -> parse qua SinhVien
				String line = br.readLine();
				if (line == null) {
					break;
				}

				String[] values = line.split(",");

				String maSV = values[0];
				String hoTen = values[1];
				boolean gioiTinhNam = Boolean.parseBoolean(values[2]);

				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
				LocalDate ngaySinh = LocalDate.parse(values[3], formatter);

				lst.add(new SinhVien(maSV, hoTen, gioiTinhNam, ngaySinh));
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return lst;
	}

	@Override
	public boolean insert(SinhVien sv) {
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename, true));) {
			bw.write(sv.getInfo());
			bw.newLine();			
			
			return true;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean xoa(String maSV) throws IOException {
		// Đọc vào list -> xóa -> ghi ra lại
		
		List<SinhVien> lst = docDanhSach();
		
		boolean removed = lst.removeIf(sv -> sv.getMaSV().equals(maSV));
		
		if (removed) {
			// Thực hiện ghi lại vào file
			
			try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename));) {
				for(SinhVien sv : lst) {
					bw.write(sv.getInfo());
					bw.newLine();
				}
			}
			return true;
		}
		
		return false;
	}

}
