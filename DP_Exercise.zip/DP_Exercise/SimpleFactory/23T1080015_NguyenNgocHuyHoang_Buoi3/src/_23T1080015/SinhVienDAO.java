package _23T1080015;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public interface SinhVienDAO {
	public List<SinhVien> docDanhSach() throws SQLException;
	public boolean insert(SinhVien sv) throws SQLException;
	public boolean xoa(String maSV) throws SQLException, IOException;
}
