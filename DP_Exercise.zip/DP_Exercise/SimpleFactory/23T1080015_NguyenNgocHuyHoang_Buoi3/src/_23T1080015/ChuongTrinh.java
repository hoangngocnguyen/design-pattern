package _23T1080015;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class ChuongTrinh {
	public static void main(String[] args) throws SQLException, IOException {
		SinhVienDAO svDao = (new SinhVienDAOFactory()).getDAO();

		// Doc file
		List<SinhVien> lst = svDao.docDanhSach();
		System.out.println("Danh sách sinh viên:");
		for (SinhVien sv : lst) {
			System.out.println(sv.getInfo());
		}

		// Thêm
		SinhVien svMoi = new SinhVien("SV09", "John Smith", true, LocalDate.of(2000, 11, 30));
		boolean inserted = svDao.insert(svMoi);
		if (inserted) {
			System.out.println("\nThêm thành công sinh viên: " + svMoi.getInfo());
		}
		
		// Xóa
		String maXoa = "SV082";
		boolean removed = svDao.xoa(maXoa);
		if (removed) {
			System.out.println("\nĐã xóa thành công sinh viên có mã " + maXoa);
		} else {
			System.out.println("Xóa thất bại hoặc không tồn tại sinh viên có mã " + maXoa);
		}
	}

}
