package _23T1080015;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DbSinhVienDAO implements SinhVienDAO {
	private String connectionString;

	public DbSinhVienDAO(String connectionString) {
		super();
		this.connectionString = connectionString;
	}

	public DbSinhVienDAO() {
		super();
	}

	@Override
	public List<SinhVien> docDanhSach() throws SQLException {
		List<SinhVien> lst = new ArrayList<SinhVien>();

		KetNoi kn = KetNoi.getInstance(connectionString);
		Connection connection = kn.getConnection();
		String query = "select * from sinhvien";

		try (PreparedStatement ps = connection.prepareStatement(query); ResultSet rs = ps.executeQuery();) {

			while (rs.next()) {
				String maSV = rs.getString("MaSinhVien");
				String hoTen = rs.getString("HoTen");
				boolean gioiTinhNam = rs.getBoolean("GioiTinhNam");
				LocalDate ngaySinhDB = rs.getObject("NgaySinh", LocalDate.class);

				lst.add(new SinhVien(maSV, hoTen, gioiTinhNam, ngaySinhDB));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return lst;
	}

	@Override
	public boolean insert(SinhVien sv) throws SQLException {
		String query = "INSERT INTO sinhvien (MaSinhVien, HoTen, GioiTinhNam, NgaySinh) VALUES (?, ?, ?, ?)";

		Connection connection = KetNoi.getInstance(connectionString).getConnection();

		try (PreparedStatement ps = connection.prepareStatement(query)) {

			ps.setString(1, sv.getMaSV());
			ps.setString(2, sv.getHoTen());
			ps.setBoolean(3, sv.isGioiTinhNam());

			ps.setObject(4, sv.getNgaySinh());

			int rowsAffected = ps.executeUpdate();

			return rowsAffected > 0; 

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean xoa(String maSV) throws SQLException {
		KetNoi kn = KetNoi.getInstance(connectionString);
		Connection connection = kn.getConnection();
		String query = "delete from sinhvien where MaSinhVien = ? ";

		try {
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setString(1, maSV);

			int rowAffects = ps.executeUpdate();

			ps.close();
			
			return rowAffects > 0;
			
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		
	}

}
