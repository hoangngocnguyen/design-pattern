package _23T1080015;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class SinhVien {
	private String maSV;
	private String hoTen;
	private boolean gioiTinhNam;
	private LocalDate ngaySinh;

	public String getMaSV() {
		return maSV;
	}

	public void setMaSV(String maSV) {
		this.maSV = maSV;
	}

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public boolean isGioiTinhNam() {
		return gioiTinhNam;
	}

	public void setGioiTinhNam(boolean gioiTinhNam) {
		this.gioiTinhNam = gioiTinhNam;
	}

	public LocalDate getNgaySinh() {
		return ngaySinh;
	}

	public void setNgaySinh(LocalDate ngaySinh) {
		this.ngaySinh = ngaySinh;
	}

	public SinhVien(String maSV, String hoTen, boolean gioiTinhNam, LocalDate ngaySinh) {
		super();
		this.maSV = maSV;
		this.hoTen = hoTen;
		this.gioiTinhNam = gioiTinhNam;
		this.ngaySinh = ngaySinh;
	}

	public SinhVien() {
		super();
		// TODO Auto-generated constructor stub
	}

	// ==== HELPER
	public String getInfo() {
		DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy/MM/dd");

		return String.format("%s,%s,%s,%s", maSV, hoTen, (gioiTinhNam ? "True" : "False"), ngaySinh.format(df));
	}

}
