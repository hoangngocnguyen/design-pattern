package vn.edu.husc.t1080015.factorymethod;

public abstract class ConVatFactory {
	abstract public ConVat getConVat();
	
	public void hello() { 
		System.out.println("I'm an implemented method");
	}
	
	protected int someAttribute;
}
