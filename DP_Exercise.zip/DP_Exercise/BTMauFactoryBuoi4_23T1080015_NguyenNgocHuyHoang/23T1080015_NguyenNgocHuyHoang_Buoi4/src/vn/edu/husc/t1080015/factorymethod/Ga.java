package vn.edu.husc.t1080015.factorymethod;

public class Ga implements ConVat {

	@Override
	public void keu() {
		System.out.println("Ò ó o");
	}
	
}