package vn.edu.husc.t1080015.factorymethod;

public class Cho implements ConVat{

	@Override
	public void keu() {
		System.out.println("Gâu gâu gâu");
	}
	
}
