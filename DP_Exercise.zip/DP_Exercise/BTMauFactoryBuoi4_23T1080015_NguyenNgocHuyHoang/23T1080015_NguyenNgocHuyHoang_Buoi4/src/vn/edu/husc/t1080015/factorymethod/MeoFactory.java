package vn.edu.husc.t1080015.factorymethod;

public class MeoFactory extends ConVatFactory{

	@Override
	public ConVat getConVat() {
		return new Meo();
	}

}
