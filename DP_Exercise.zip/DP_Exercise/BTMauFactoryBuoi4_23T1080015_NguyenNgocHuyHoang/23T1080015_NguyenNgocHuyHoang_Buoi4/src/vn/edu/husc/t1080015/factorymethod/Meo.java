package vn.edu.husc.t1080015.factorymethod;

public class Meo implements ConVat {

	@Override
	public void keu() {
		System.out.println("Meo meo");
	}
	
}
