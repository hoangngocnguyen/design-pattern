package vn.edu.husc.t1080015.factorymethod.ui;

import vn.edu.husc.t1080015.factorymethod.ChoFactory;
import vn.edu.husc.t1080015.factorymethod.ConVat;
import vn.edu.husc.t1080015.factorymethod.ConVatFactory;
import vn.edu.husc.t1080015.factorymethod.GaFactory;
import vn.edu.husc.t1080015.factorymethod.MeoFactory;

public class ChuongTrinh {
	public static void main(String[] args) {
		test();
	}

		private static void test() {
		String loai = "Meo";
		System.out.println("Loai: " + loai);
		
		// Khai báo
		ConVat x;
		ConVatFactory f;
		
		// Tao nha may theo config chuong trinh
		if (loai.equals("Meo")) {
			f = new MeoFactory();
		} else if (loai.equals("Cho")) {
			f = new ChoFactory();
		} else {
			f = new GaFactory();
		}
		
		// Tao con vat
		x = f.getConVat();
		
		
		// Hanh vi
		x.keu();
		
	}
}
