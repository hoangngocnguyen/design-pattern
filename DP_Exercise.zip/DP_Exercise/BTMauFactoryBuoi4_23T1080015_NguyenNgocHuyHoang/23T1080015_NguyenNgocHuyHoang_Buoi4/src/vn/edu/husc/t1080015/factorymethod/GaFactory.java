package vn.edu.husc.t1080015.factorymethod;

public class GaFactory extends ConVatFactory{

	@Override
	public ConVat getConVat() {
		return new Ga();
	}
	
}
