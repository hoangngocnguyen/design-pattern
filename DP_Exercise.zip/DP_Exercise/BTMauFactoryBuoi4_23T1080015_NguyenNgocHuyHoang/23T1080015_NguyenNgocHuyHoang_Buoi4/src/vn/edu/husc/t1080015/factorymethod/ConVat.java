package vn.edu.husc.t1080015.factorymethod;

public interface ConVat {
	void keu();
}
