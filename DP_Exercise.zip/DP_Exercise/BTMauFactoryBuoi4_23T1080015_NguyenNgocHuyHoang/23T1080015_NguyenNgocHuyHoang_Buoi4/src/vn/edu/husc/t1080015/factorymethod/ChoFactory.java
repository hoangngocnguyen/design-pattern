package vn.edu.husc.t1080015.factorymethod;

public class ChoFactory extends ConVatFactory {

	@Override
	public ConVat getConVat() {
		return new Cho();
	}

}
