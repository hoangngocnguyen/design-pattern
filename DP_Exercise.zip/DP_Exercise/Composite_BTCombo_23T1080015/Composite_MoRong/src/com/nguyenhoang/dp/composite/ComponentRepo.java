package com.nguyenhoang.dp.composite;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class ComponentRepo {
	private int insert(Component c, Integer parentId) throws SQLException {
		String sql = "INSERT INTO ThanhPhans (Ten, DungLuong, Loai, ParentId) VALUES (?, ?, ?, ?)";
		KetNoi kn = new KetNoi();
		try (Connection conn = kn.cn;
				PreparedStatement ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

			// 1. set tên
			if (c instanceof File) {
				File f = (File) c;
				ps.setString(1, f.getName());
				ps.setInt(2, (int) f.getTotalSize());
				ps.setString(3, "File");
			} else {
				Folder f = (Folder) c;
				ps.setString(1, f.getName());
				ps.setNull(2, java.sql.Types.INTEGER);
				ps.setString(3, "Folder");
			}

			// 2. parentId
			if (parentId == null) {
				ps.setNull(4, java.sql.Types.INTEGER);
			} else {
				ps.setInt(4, parentId);
			}

			// 3. execute
			ps.executeUpdate();

			// 4. lấy ID vừa insert
			try (ResultSet rs = ps.getGeneratedKeys()) {
				if (rs.next()) {
					return rs.getInt(1); // ID mới
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return -1;
	}

	public void save(Component c, Integer parentId) throws SQLException {
		// Lấy id Component vừa insert
		int id = insert(c, parentId);

		// Nếu là File thì không làm gì
		// Nếu là Folder thì duyệt các item trong nó rồi insert dần dần
		if (c instanceof Folder) {
			Folder f = (Folder) c;
			for (Component child : f.getLstItem()) {
				save(child, id);
			}
		}
	}

	public Component doc() throws SQLException {
		String sql = "SELECT Id, Ten, DungLuong, Loai, ParentId FROM ThanhPhans";
		KetNoi kn = new KetNoi();

		Map<Integer, Component> map = new HashMap<>();
		Map<Integer, Integer> parentMap = new HashMap<>();

		Component root = null;

		try (Connection conn = kn.cn;
				PreparedStatement ps = conn.prepareStatement(sql);
				ResultSet rs = ps.executeQuery()) {

			// 🔹 Bước 1: tạo object
			while (rs.next()) {
				int id = rs.getInt("Id");
				String ten = rs.getString("Ten");
				String loai = rs.getString("Loai");
				Integer parentId = (Integer) rs.getObject("ParentId");

				Component c;

				if ("File".equals(loai)) {
					int size = rs.getInt("DungLuong");
					c = new File(ten, size);
				} else {
					Folder f = new Folder();
					f.setName(ten);
					c = f;
				}

				map.put(id, c);
				parentMap.put(id, parentId);
			}

			// 🔹 Bước 2: nối cây
			// Duyệt từng id
			for (Integer id : map.keySet()) {
				// Lấy node 
				Component child = map.get(id);
				
				// Lấy id node cha
				Integer parentId = parentMap.get(id);

				if (parentId == null) {
					// Nếu không có node cha thì là root
					root = child;
				} else {
					// Lấy ra node cha từ [id cha]
					Folder parent = (Folder) map.get(parentId);

					// Thêm node con vào list node cha
					parent.getLstItem().add(child);
				}
			}
		}

		return root;
	}
}
