package com.nguyenhoang.dp.composite;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KetNoi {
	public Connection cn;
	
	public KetNoi() throws SQLException {
		String URL = "jdbc:sqlserver://localhost:1433;databaseName=FileSystemDB;encrypt=true;trustServerCertificate=true";
		String USER = "sa"; 
		String PASSWORD = "123456"; 
		this.cn = DriverManager.getConnection(URL, USER, PASSWORD);
		System.out.println("Kết nối csdl thành công");
	}
	
}