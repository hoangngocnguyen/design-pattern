package com.nguyenhoang.dp.composite;

import java.util.ArrayList;
import java.util.List;

@lombok.AllArgsConstructor
@lombok.Data
@lombok.NoArgsConstructor
public class Folder implements Component {
	private String name;
	
	// DS doi tuong trong thu muc
	private List<Component> lstItem = new ArrayList<>();

	@Override
	public long getTotalSize() {
		long rs = 0;
		for (Component c : lstItem) {
			rs += c.getTotalSize();
		}
		
		return rs;
	}
	
	@Override
	public String getPath(String targetName) {
		if (this.name.equals(targetName)) {
			return this.name;
		}
		
		for (Component c : lstItem) {
			String path = c.getPath(targetName);
			
			if (path != null) {
				return this.name + "/" + path;
			}
		}
		
		return null;
	}
}
