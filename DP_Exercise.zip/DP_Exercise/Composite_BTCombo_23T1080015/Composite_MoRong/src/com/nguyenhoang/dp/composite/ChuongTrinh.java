package com.nguyenhoang.dp.composite;

import java.sql.SQLException;
import java.util.Arrays;

public class ChuongTrinh {
	public static void main(String[] args) throws SQLException {
		/*
		LAPTRINH
		|__JAVA
		|    |__baitap01 (5 kb)
		|    |__baitap02 (3 kb)
		|    |__LYTHUYET
		|        |__abc (12 kb)
		|__C#
		|__test (1 kb)		 
		*/
		Component baitap01 	= new File("baitap01", 5);
		Component baitap02 	= new File("baitap02", 3);
		Component abc 		  = new File("abc", 12);
		Component test 		  = new File("test", 1);
		
		Component LYTHUYET 	= new Folder("LY THUYET", Arrays.asList(abc));
		Component JAVA 		  = new Folder("JAVA", Arrays.asList(baitap01, baitap02, LYTHUYET));
		Component CSHARP 	  = new Folder("C#", Arrays.asList());		
		Component LAPTRINH 	= new Folder("LAP TRINH", Arrays.asList(JAVA, CSHARP, test));
		
		
		ComponentRepo repo = new ComponentRepo();
//		repo.save(LAPTRINH, null);
		
		// In cấu trúc đường dẫn LAPTRINH
		Component root = repo.doc();
		
		System.out.println(getCauTrucCay(root,0));
	}
	
	public static String getCauTrucCay(Component c, int cap) {
		String indent = "";

	    // tạo khoảng trắng theo cap
	    for (int i = 0; i < cap; i++) {
	        indent += "\t";
	    }
		
		if (c instanceof File) {
			return ( indent + "|__" + ((File) c).getName() + "\n");
		}
		
		// Nếu là folder
		Folder f = (Folder) c;
		String tm =  indent + "|__" + ((Folder) f).getName() + "\n";
		for (Component child : f.getLstItem()) {
			tm += "" + getCauTrucCay(child, cap+1);
		}
		return tm;
	}
}
