package com.nguyenhoang.dp.composite;

@lombok.AllArgsConstructor
@lombok.Data
public class File implements Component{
	private String name;
	private long size;
	
	
	public long getTotalSize() {
		return this.size;
	}
	
	@Override
	public String getPath(String targetName) {
		if (this.name.equals(targetName)) {
			return this.name;
		}
		return null;
	}
	
}
