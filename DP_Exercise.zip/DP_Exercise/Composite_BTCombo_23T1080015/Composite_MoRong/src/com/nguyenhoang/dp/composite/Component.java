package com.nguyenhoang.dp.composite;


public interface Component {
	long getTotalSize();
	String getPath(String targetName);
	
}
