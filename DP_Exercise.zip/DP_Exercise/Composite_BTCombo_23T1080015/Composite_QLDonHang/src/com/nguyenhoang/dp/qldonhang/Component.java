package com.nguyenhoang.dp.qldonhang;

public interface Component {
	double getTongTien();
	String getCay(int cap);
}
