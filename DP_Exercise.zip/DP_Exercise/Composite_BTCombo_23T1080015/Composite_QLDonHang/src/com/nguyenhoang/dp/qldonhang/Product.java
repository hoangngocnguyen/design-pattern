package com.nguyenhoang.dp.qldonhang;

@lombok.Builder
@lombok.AllArgsConstructor
@lombok.Data
@lombok.NoArgsConstructor
public class Product implements Component {
	private String ten;
	private double gia;
	private int soluong;

	@Override
	public double getTongTien() {
		return gia * soluong;
	}

	@Override
	public String getCay(int cap) {
		String indent = "|    ".repeat(cap);
		return String.format("%s|-- %s (x %d)\n", indent, ten, soluong);
	}
}
