package com.nguyenhoang.dp.qldonhang;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KetNoi {
	private static KetNoi _instance = null;
	private Connection cn;
	
	
	private KetNoi() throws SQLException {
		String url = "jdbc:sqlserver://localhost:1433;databaseName=QLDonHang;encrypt=true;trustServerCertificate=true";
		String username = "sa";
		String password = "123456";
		
		this.cn = DriverManager.getConnection(url, username, password);
		System.out.println("Kết nối csdl thành công");
	}
	
	
	public static KetNoi getInstance() throws SQLException {
		if (_instance == null) {
			_instance = new KetNoi();
			
		}
		return _instance;
		
	}
	
	public Connection getConnection() {
		return cn;
	}
	
}
