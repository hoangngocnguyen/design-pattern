package com.nguyenhoang.dp.qldonhang;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;


public class ComponentRepo {
	// Doc
	public Component doc() throws SQLException {
		// 0. Khởi tạo 2 map lưu node và id cha
		Map<Integer, Component> map = new HashMap<>();
		Map<Integer, Integer> parentMap = new HashMap<>();
		Component root = null;
		
		// 1. Kết nối csdl
		KetNoi kn = KetNoi.getInstance();
		String sql = "select Id, Ten, Gia, Loai, SoLuong, ParentId from ThanhPhans";
		
		// 2. Thực hiện truy vấn
		try(PreparedStatement ps = kn.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery()) {

			// 3. Ánh xạ kết quả ra
			while(rs.next()) {
				int id = rs.getInt("Id");
				String ten = rs.getString("Ten");
				Double gia = rs.getDouble("Gia");
				String loai = rs.getString("Loai");
				Integer soluong = rs.getInt("SoLuong");
				Integer parentId = (Integer) rs.getObject("ParentId");
				
				Component c;
				if ("Product".equals(loai)) {
					Product p = new Product.ProductBuilder()
							.ten(ten).soluong(soluong)
							.gia(gia).build();
					c = p;
				} else {
					Combo cb = new Combo(ten);
					c = cb;
				}
				
				// Đưa vào map
				map.put(id, c);
				parentMap.put(id, parentId);
				
			}
		}
		
		// 4. Nối cây
		// Duyệt từng id
		for (Integer id : map.keySet()) {
			// Lấy node con
			Component child = map.get(id);
			
			// Lấy id node cha
			Integer parentId = parentMap.get(id);
			
			// Nếu không có node cha thì là root
			if (parentId == null) {
				root = child;
			} else {
				// Lấy ra node cha từ [id cha] (chắc chắn là kiểu combo)
				Combo parent = (Combo) map.get(parentId);
				
				// Thêm node con vào list node cha
				parent.getLstItem().add(child);
			}
		}
		
		return root;
	}
	
	
	// Ghi
	public void ghi(Component component) {
		//
	}
}
