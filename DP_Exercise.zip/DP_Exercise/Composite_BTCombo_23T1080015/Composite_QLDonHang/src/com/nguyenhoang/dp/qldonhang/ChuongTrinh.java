package com.nguyenhoang.dp.qldonhang;

import java.sql.SQLException;

public class ChuongTrinh {
	public static void main(String[] args) throws SQLException {
//		test1();
		
		ComponentRepo repo = new ComponentRepo();
		Component root = repo.doc();
		System.out.println("Cấu trúc: \n " + root.getCay(0));
		
		System.out.println("Tổng tiền: " + root.getTongTien());
	}

	private static void test1() {
		Combo root = new Combo("Don hang");

		Product ban = new Product("Ban", 100, 2);
		Product ghe = new Product("Ghe", 50, 4);

		Combo comboPhong = new Combo("Combo phong");
		comboPhong.add(ban);
		comboPhong.add(ghe);

		root.add(comboPhong);

		System.out.println(root.getCay(0));
		System.out.println("Tong tien: " + root.getTongTien());
	}
}
