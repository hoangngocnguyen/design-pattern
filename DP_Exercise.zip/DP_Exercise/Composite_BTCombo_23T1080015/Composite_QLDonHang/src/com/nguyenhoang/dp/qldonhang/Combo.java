package com.nguyenhoang.dp.qldonhang;

import java.util.ArrayList;
import java.util.List;

@lombok.AllArgsConstructor
@lombok.Data
@lombok.NoArgsConstructor
public class Combo implements Component {
	private String ten;

	private List<Component> lstItem = new ArrayList<>();
	
	public Combo(String ten) {
		this.setTen(ten);
	}
	
	public void add(Component com) {
		lstItem.add(com);
	}

	@Override
	public double getTongTien() {
		// Duyet + tinh tien
		double total = 0;
		for (Component c : lstItem) {
			total += c.getTongTien();
		}

		return total;
	}

	@Override
	public String getCay(int cap) {
		String indent = "|    ".repeat(cap);
		
		String rs = String.format("%s|-- %s\n", indent, ten);
		
		for (Component c : lstItem) {
			rs += c.getCay(cap + 1);
		}

		return rs;
	}

}
