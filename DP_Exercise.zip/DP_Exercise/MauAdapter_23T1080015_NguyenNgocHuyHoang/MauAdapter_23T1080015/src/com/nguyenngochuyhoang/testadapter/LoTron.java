package com.nguyenngochuyhoang.testadapter;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@lombok.Data
@AllArgsConstructor
@NoArgsConstructor
public class LoTron {
	private double banKinh;
	
	// kiem tra coc co chui qua lo
	public boolean isFit(CocTron x) {
			return this.getBanKinh() >= x.getBanKinh();
	}
	
}
