package com.nguyenngochuyhoang.testadapter;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@lombok.Data
@AllArgsConstructor
@NoArgsConstructor
public class CocTron {
	private double banKinh;
	private double chieuDai;
	
	public String toString() {
		return String.format("[Dài %.2f, Bán kính %.2f]", 
				this.getChieuDai(),
				this.getBanKinh());
	}
}
