package com.nguyenngochuyhoang.testadapter;

public class ChuongTrinh {
	public static void main(String[] args) {
		
		LoTron x = new LoTron(2);
		
		CocTron y = new CocTron(2, 8);
		
		// Kiểm tra cọc tròn y có vừa lỗ x
		System.out.println("Cọc tròn " + y.toString() + " vừa với lỗ tròn " + x.toString() + ":" + x.isFit(y));

		CocVuong z = new CocVuong(3);
		// Kiểm tra xem cọc vuông z có vừa với lỗ x hay không
		CocTronCuaCocVuong z2 = new CocTronCuaCocVuong(z);
		
		System.out.println("Cọc vuông " + z.toString() + " vừa với lỗ tròn " + x.toString() + ":" + x.isFit(z2));
	}
}
