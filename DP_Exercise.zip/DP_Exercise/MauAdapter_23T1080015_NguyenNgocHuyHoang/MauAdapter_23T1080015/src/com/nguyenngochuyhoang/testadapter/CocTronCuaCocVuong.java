package com.nguyenngochuyhoang.testadapter;


public class CocTronCuaCocVuong extends CocTron {
	private CocVuong x;

	public CocTronCuaCocVuong(CocVuong x) {
		this.x = x;
	}

	
	@Override
	public double getBanKinh() {
		return x.getKichThuoc() * Math.sqrt(0.5);
	}
}
