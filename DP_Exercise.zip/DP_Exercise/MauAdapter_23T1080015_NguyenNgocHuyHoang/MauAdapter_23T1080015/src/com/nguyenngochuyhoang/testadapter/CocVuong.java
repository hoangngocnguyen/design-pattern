package com.nguyenngochuyhoang.testadapter;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@lombok.Data
@AllArgsConstructor
@NoArgsConstructor
public class CocVuong {
	private double kichThuoc;

}
