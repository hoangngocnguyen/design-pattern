package vn.edu.husc.t1080015;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class XeRepo {
	
	// Yeu cau 2
	public static List<ThongTinVe> docDanhSachXe1() throws ParseException {
		List<ThongTinVe> lst = new ArrayList<ThongTinVe>();

		try (BufferedReader br = new BufferedReader(new FileReader("input1.txt"))) {
			while (true) {
				String line = br.readLine();
				if (line == null) {
					break;
				}

				String[] values = line.split(";");

				// 5 value:
				Integer loaiXe = Integer.parseInt(values[0]);
				String bienSo = values[1].equals("Not Available") ? null : values[1];

				String soVeXe = values[2].equals("Not Available") ? null : values[2];
				
				SimpleDateFormat sdf = new SimpleDateFormat("H:mm dd/MM/yyyy");

				Date thoiGianVao = sdf.parse(values[3]);
				String tinhTrangLucVao = values[4].equals("Not Available") ? null : values[4];


				// them vao lst Xe theo tung loai

				ThongTinVe xe = new ThongTinVe();
				if (loaiXe == 4) {
					xe.setLoaiXe(loaiXe);
					xe.setBienSo(bienSo);
					xe.setThoiDiemVao(thoiGianVao);
					xe.setTinhTrangKhiVao(tinhTrangLucVao);

				} else if (loaiXe == 2) {
					xe.setLoaiXe(loaiXe);
					xe.setBienSo(bienSo);
					xe.setThoiDiemVao(thoiGianVao);

				} else if (loaiXe == 0) {
					xe.setLoaiXe(loaiXe);
					xe.setSoVe(soVeXe);
					xe.setThoiDiemVao(thoiGianVao);
				}
				lst.add(xe);
			}

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return lst;
	}
	
	// Yeu cau 5
	
	public static List<ThongTinVe> docDanhSachXeRa() throws ParseException{
	    // 1. Lấy danh sách xe đã vào từ file input1.txt
	    List<ThongTinVe> danhSachVao = docDanhSachXe1();
	    List<ThongTinVe> lstKetQua = new ArrayList<>();

	    try (BufferedReader br = new BufferedReader(new FileReader("input2.txt"))) {
	        String line;
	        SimpleDateFormat sdf = new SimpleDateFormat("H:mm dd/MM/yyyy");

	        while ((line = br.readLine()) != null) {
	            String[] values = line.split(";");

	            Integer loaiXe = Integer.parseInt(values[0]);
	            String bienSo = values[1].equals("Not Available") ? null : values[1];
	            String soVeXe = values[2].equals("Not Available") ? null : values[2];
	            Date thoiGianRa = sdf.parse(values[3]);
	            String tinhTrangLucRa = values[4].equals("Not Available") ? null : values[4];

	            // 2. Tìm xe tương ứng trong danh sách đã vào
	            ThongTinVe xeTimThay = null;
	            for (ThongTinVe x : danhSachVao) {
	                if (loaiXe == 0) {
	                    // Xe đạp: Tìm theo số vé
	                    if (x.getLoaiXe() == 0 && x.getSoVe().equals(soVeXe)) {
	                        xeTimThay = x;
	                        break;
	                    }
	                } else {
	                    // Xe máy/ô tô: Tìm theo biển số
	                    if (x.getLoaiXe() == loaiXe && x.getBienSo().equals(bienSo)) {
	                        xeTimThay = x;
	                        break;
	                    }
	                }
	            }

	            // 3. Nếu tìm thấy, cập nhật thông tin Ra và add vào list kết quả
	            if (xeTimThay != null) {
	                xeTimThay.setThoiDiemRa(thoiGianRa);
	                xeTimThay.setTinhTrangKhiRa(tinhTrangLucRa);
	                lstKetQua.add(xeTimThay);
	            }
	        }

	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    return lstKetQua;
	}
	
	// Tính block
	public static int getBlockTime(Date vao, Date ra, int minute) {
	    long diffInMillies = ra.getTime() - vao.getTime();
	    
	    double soPhut = (double) diffInMillies / 60000;
	    
	    // Tính block giờ
	    int result = (int) Math.ceil(soPhut / minute);
	    
//	    System.out.println("Số phút thực tế: " + soPhut + " ------- Số block làm tròn: " + result);
	    
	    return result;
	}
	
	
	
	public static void xuatThongTin(List<ThongTinVe> lst) {
		try (BufferedWriter bw = new BufferedWriter(new FileWriter("output.txt"))) {
			
			for (ThongTinVe xe : lst) {
				bw.write(xe.getInfo() + "\n");
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
