package vn.edu.husc.t1080015;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

public class ChuongTrinh {
	public static void main(String[] args) throws ParseException {
		
		System.out.println("--- BẮT ĐẦU ĐỌC DANH SÁCH XE VÀO (INPUT 1) ---");
		
        // YC 2
        List<ThongTinVe> danhSachXeIn = XeRepo.docDanhSachXe1();
        System.out.println("Đã đọc xong " + danhSachXeIn.size() + " xe từ input1.txt");
        
        // YC5
        System.out.println("\n--- BẮT ĐẦU XỬ LÝ XE RA (INPUT 2) ---");
        List<ThongTinVe> danhSachXeOut = XeRepo.docDanhSachXeRa(); 
        
        // YC6
//        System.out.println("\n--- KẾT QUẢ THÔNG TIN XE RA ---");
//        for (ThongTinVe xe : danhSachXeOut) {
//            if (xe != null) {
//                System.out.println(xe.getInfo());
//            } else {
//                System.out.println("Không tìm thấy thông tin xe tương ứng trong hệ thống.");
//            }
//        }
        
        XeRepo.xuatThongTin(danhSachXeOut);
	}
}
