package vn.edu.husc.t1080015;

import java.text.SimpleDateFormat;
import java.util.Date;


@lombok.Data
public class ThongTinVe {
	private Date thoiDiemVao;
	private Date thoiDiemRa = null;
	private String soVe;
	private String bienSo;
	private String tinhTrangKhiVao;
	private String tinhTrangKhiRa;

	private int loaiXe; // 0, 2, 4

	

	// GetTienThue
	public double getTienThue() {
		if (this.loaiXe == 4) {
			if (!this.getTinhTrangKhiRa().equals("Binh thuong")) {
				return 0f;
			}

			int block = XeRepo.getBlockTime(this.thoiDiemVao, this.thoiDiemRa, 30);

			return block * 5000;
		} else if (this.loaiXe == 2) {
			int block = XeRepo.getBlockTime(this.thoiDiemVao, this.thoiDiemRa, 3600);
			return block * 3000;

		} else if (this.loaiXe == 0) {
			int block = XeRepo.getBlockTime(this.thoiDiemVao, this.thoiDiemRa, 3600);
			return block * 1000;
		}
		
		return 0f;
	}

	// In thong tin xe
	// In thong tin xe
	public String getInfo() {
	    // 1. Khởi tạo formatter với định dạng yêu cầu
	    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm dd/MM/yyyy");
	    
	    // 2. Chuyển đổi Date sang String, kiểm tra null để tránh lỗi
	    String vaoStr = (this.getThoiDiemVao() != null) ? sdf.format(this.getThoiDiemVao()) : "Not Available";
	    String raStr = (this.getThoiDiemRa() != null) ? sdf.format(this.getThoiDiemRa()) : "Not Available";

	    // 3. Xử lý logic theo từng loại xe
	    if (this.loaiXe == 4) {
	        // Kiểm tra tiền thuê: nếu = 0 thì trả về thông báo bồi thường, ngược lại ép kiểu sang long để dùng %d
	        String tienThueStr = (this.getTienThue() == 0) 
	                ? "Chua xac dinh - Dang xu ly boi thuong" 
	                : String.format("%d", (long) this.getTienThue());

	        return String.format("%d, %s, Not Available, %s, %s, %s",
	                this.getLoaiXe(), 
	                this.getBienSo(),
	                vaoStr,
	                raStr,
	                tienThueStr
	                );
	                
	    } else if (this.loaiXe == 2) {
	        // Xe máy: Ép kiểu (long) để tương thích với %d
	        return String.format("%d, %s, Not Available, %s, %s, %d", 
	                this.getLoaiXe(), 
	                this.getBienSo(),
	                vaoStr, 
	                raStr,
	                (long) this.getTienThue());
	                
	    } else if (this.loaiXe == 0) {
	        // Xe đạp: Dùng getSoVe() và ép kiểu (long)
	        return String.format("%d, Not Available, %s, %s, %s, %d", 
	                this.getLoaiXe(), 
	                this.getSoVe(),
	                vaoStr, 
	                raStr,
	                (long) this.getTienThue());
	    }
	    
	    return "";
	}
}
