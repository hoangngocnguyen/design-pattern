package com.nnhhoang.dp.proxy;

import java.util.List;

public interface NhanVienServiceInterface {
	public List<NhanVien> getDanhSachNhanVien();
}