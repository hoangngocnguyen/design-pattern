package com.nnhhoang.dp.proxy;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NhanVienServiceImpl implements NhanVienServiceInterface {

	@Override
	public List<NhanVien> getDanhSachNhanVien() {
	    List<NhanVien> empList = new ArrayList<>();
	    
	    String sql = "SELECT hoTen, heSoLuong, chucVu FROM NhanVien"; 
	    
	    try (
	        Connection cn = KetNoi.getInstance().getConnection();
	        
	        PreparedStatement pstm = cn.prepareStatement(sql);
	        
	        ResultSet rs = pstm.executeQuery()
	    ) {
	        
	        while (rs.next()) {
	            String hoTen = rs.getString("hoTen");
	            double heSoLuong = rs.getDouble("heSoLuong");
	            String chucVu = rs.getString("chucVu");
	            
	            NhanVien nv = new NhanVien(hoTen, heSoLuong, chucVu);
	            empList.add(nv);
	        }
	        
	    } catch (SQLException e) {
	        System.out.println("Lỗi khi đọc dữ liệu từ Database: " + e.getMessage());
	        e.printStackTrace();
	    }
	    
	    return empList;
	}
}