package com.nnhhoang.dp.proxy;

import java.util.List;

public class NhanVienServiceProxy implements NhanVienServiceInterface { // IS-A

	private NhanVienServiceInterface svcNhanVien = null; // HAS-A

	@Override
	public List<NhanVien> getDanhSachNhanVien() {
			if (svcNhanVien == null) {
					System.out.println("Khởi tạo service THẬT SỰ...");
					svcNhanVien = new NhanVienServiceImpl();
			}
			return svcNhanVien.getDanhSachNhanVien();
	}
}