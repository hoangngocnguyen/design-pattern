package com.nnhhoang.dp.proxy;

import java.util.List;

public class ChuongTrinh {
	public static void main(String[] args) {			
		System.out.println("Sử dụng service...");
		NhanVienServiceInterface service = new NhanVienServiceProxy();
		List<NhanVien> lst = service.getDanhSachNhanVien(); // Thuc su thuc hien loi goi ham truy xuat dich vu
		for (NhanVien x : lst) {
				System.out.println(x);
		}
}
}
