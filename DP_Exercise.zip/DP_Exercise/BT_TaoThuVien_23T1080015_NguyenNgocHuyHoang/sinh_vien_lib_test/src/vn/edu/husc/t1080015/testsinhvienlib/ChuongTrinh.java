package vn.edu.husc.t1080015.testsinhvienlib;

import java.io.IOException;
import java.util.List;

import vn.edu.husc.t1080015.SinhVien;
import vn.edu.husc.t1080015.SinhVienReader;

public class ChuongTrinh {
	public static void main(String[] args) {
		testSinhVienLib();
	}

	private static void testSinhVienLib() {
		SinhVien sv1;
		
		sv1 = new SinhVien();
		sv1.setMaSinhVien("23T1080015");
		sv1.setHoDem("Nguyen");
		sv1.setTen("Hoang");
		sv1.setDiemTrungBinh(10);
		
		System.out.println(sv1.getHoDem() + " " + sv1.getTen());
		
		
		System.out.println("Danh sách sinh viên đọc từ file:");
		try {
			List<SinhVien> lst = SinhVienReader.readFromFile("sinhvien.txt");
			
			for (SinhVien sv : lst) {
				System.out.println(sv.getMaSinhVien() + " " + sv.getHoDem() + " " + sv.getTen());
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	}
}
