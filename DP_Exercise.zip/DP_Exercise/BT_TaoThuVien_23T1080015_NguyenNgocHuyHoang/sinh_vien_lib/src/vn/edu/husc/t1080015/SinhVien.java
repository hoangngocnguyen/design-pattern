package vn.edu.husc.t1080015;

@lombok.AllArgsConstructor 
@lombok.NoArgsConstructor
@lombok.Getter
@lombok.Setter
public class SinhVien {
		private String maSinhVien;
		private String hoDem;
		private String ten;
		private double diemTrungBinh;
}
